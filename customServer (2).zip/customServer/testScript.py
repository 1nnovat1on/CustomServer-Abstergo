

print("Hello World")