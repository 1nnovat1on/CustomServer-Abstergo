.. Call Center Validation Flags documentation master file, created by
   sphinx-quickstart on Thu Apr 28 09:15:43 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Call Center Validation Flags's documentation!
========================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
